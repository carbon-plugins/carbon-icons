<?php return array('dependencies' => array('wp-blocks', 'wp-data', 'wp-dom-ready', 'wp-i18n'), 'version' => 'e21c1eb7580691c20cdb');
